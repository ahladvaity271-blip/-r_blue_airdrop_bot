# Optional minimal Telegram bot launcher example.
# Install: pip install python-telegram-bot
# Set BOT_TOKEN as an environment variable.
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes

WEBAPP_URL = os.getenv("WEBAPP_URL", "https://YOUR-DOMAIN.example/")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb=[[InlineKeyboardButton("🪙 Open Coins App", web_app=WebAppInfo(url=WEBAPP_URL))]]
    await update.message.reply_text("Open the app:", reply_markup=InlineKeyboardMarkup(kb))

app=Application.builder().token(os.environ["BOT_TOKEN"]).build()
app.add_handler(CommandHandler("start", start))
app.run_polling()
