const tg=window.Telegram?.WebApp; tg?.ready(); tg?.expand();
const KEY='monetag_demo_state_v1';
let state=JSON.parse(localStorage.getItem(KEY)||'null')||{coins:0,ads:0,wins:0,losses:0};
const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
function render(){$('coins').textContent=state.coins;$('coins2').textContent=state.coins;$('ads').textContent=state.ads;$('ads2').textContent=state.ads;$('wins').textContent=state.wins;$('losses').textContent=state.losses}
render();

$('adBtn').onclick=async()=>{
  const btn=$('adBtn'); btn.disabled=true; btn.textContent='⏳ Loading Ad...';
  try{
    if(typeof show_11755684!=='function') throw new Error('Ad SDK not loaded');
    await show_11755684();
    state.coins+=5; state.ads+=1; save();
    $('result').textContent='✅ Ad completed! +5 Coins';
    $('result').className='result success';
  }catch(e){
    $('result').textContent='❌ Ad was not completed.';
    $('result').className='result danger';
  }finally{btn.disabled=false;btn.textContent='📺 Watch Ad +5 Coins'}
};

$('playBtn').onclick=()=>{
  const bet=Math.floor(Number($('bet').value));
  if(!Number.isFinite(bet)||bet<10){msg('Minimum bet is 10 Coins.','danger');return}
  if(bet>state.coins){msg('Not enough Coins.','danger');return}
  state.coins-=bet;
  // Demo game: 45% win chance. Replace with server-side RNG for production.
  const win=Math.random()<0.45;
  if(win){const reward=bet*2;state.coins+=reward;state.wins++;msg(`🍎 You WIN! +${reward} Coins`,'success')}
  else{state.losses++;msg(`💥 You LOSE! -${bet} Coins`,'danger')}
  save();
};
function msg(t,c){$('result').textContent=t;$('result').className='result '+c}
