# Monetag Telegram Web App

This starter project uses the supplied Monetag SDK:
- Zone: 11755684
- Reward: +5 Coins after `show_11755684()` resolves
- Ads Watched counter
- Apple of Fortune demo game, minimum bet 10 Coins
- Win/Lose counters

## Important
This is a FRONT-END DEMO. Coins are stored in localStorage, so it is NOT suitable for real-money/valuable rewards.

For production, add a backend (Node.js/Python/PHP) and database. The server should authenticate the Telegram user, validate ad rewards according to Monetag's official reward documentation, and perform game balance/RNG logic server-side.

## Run
Host the folder on HTTPS. Set the hosted URL as your Telegram Web App URL through BotFather.

Do not put your Telegram Bot Token in this folder or in browser JavaScript.
